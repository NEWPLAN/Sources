#ifndef UTF_UTIL_H__
#define UTF_UTIL_H__

#ifdef __cplusplus
extern "C"
{
#endif

WCHAR* utf8_to_utf16(const char *txt);

#ifdef __cplusplus
}
#endif

#endif
